﻿class Launcher
{
    public static void Main()
    {
        //LinkedList<int> temp = new LinkedList<int>();
        //temp.AddFirst(5);
        //temp.AddFirst(4);
        //temp.AddFirst(3);
        //temp.AddFirst(2);
        //temp.AddFirst(1);
        //var test = temp.RemoveFirst();
        //test = temp.RemoveFirst();
        //System.Console.WriteLine();
    }
}
