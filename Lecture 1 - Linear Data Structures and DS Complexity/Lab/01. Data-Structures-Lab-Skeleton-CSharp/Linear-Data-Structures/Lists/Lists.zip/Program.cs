﻿public class Program
{
    public static void Main(string[] args)
    {
        //ArrayList<int> test = new ArrayList<int>();

        //test.Add(11);
        //test.Add(12);
        //test.Add(13);
        //test.Add(14);
        //test.RemoveAt(0);
        //test.RemoveAt(0);
        //test.RemoveAt(0);

        //System.Console.WriteLine();

    }
}
