﻿using System;
   public class Program
    {
        static void Main(string[] args)
        {
            //ReversedList<int> test = new ReversedList<int>();

            //test.Add(1);
            //test.Add(2);
            //test.Add(3);
            //test.Add(4);
            //test.Add(5);
            //test.Add(6);
            //test.RemoveAt(0);

            //Console.WriteLine(string.Join(" ", test));
            //Console.WriteLine();
        }
    }

